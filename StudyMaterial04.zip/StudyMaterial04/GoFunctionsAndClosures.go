
package main

import "fmt"
import "math"

//______________________________________________________

func division( dividend int, divisor int) (int, int) {
	if divisor != 0 {
		quotient 	:= dividend / divisor
		remainder 	:= dividend % divisor

		return quotient, remainder
	} else {
		fmt.Println("Error: Division By Zero!")
	}
	return 0, -1
}

func divisionAgain( dividend, divisor int) (int, int) {
	if divisor != 0 {
		quotient 	:= dividend / divisor
		remainder 	:= dividend % divisor

		return quotient, remainder
	} else {
		fmt.Println("Error: Division By Zero!")
	}
	return 0, -1
}

func divisionOnceAgain( dividend, divisor int) (quotient, remainder int) {
	if divisor != 0 {
		quotient 	:= dividend / divisor
		remainder 	:= dividend % divisor

		return quotient, remainder
	} else {
		fmt.Println("Error: Division By Zero!")
	}
	return 0, -1
}

func playWithDivsion() {
	q, r := division( 10, 3 )
	fmt.Printf("\nQuotient: %d Remainder: %d", q, r )

	qq, rr := divisionAgain( 10, 3 )
	fmt.Printf("\nQuotient: %d Remainder: %d", qq, rr )

	qqq, rrr := divisionOnceAgain( 10, 3 )
	fmt.Printf("\nQuotient: %d Remainder: %d", qqq, rrr )

}

//______________________________________________________

func playWithClosures() {
	var x, y = 40, 20
	var result = 0

	// Closures/Lambdas
	// 		Anonmous Functions
	add := func( x, y int ) int { return x + y }
	sub := func( x, y int ) int { return x - y }

	result = add( x, y )
	fmt.Println("Result: ", result)

	result = sub( x, y )
	fmt.Println("Result: ", result)
}

//______________________________________________________


// Function Type
//		(int, int) -> int

func sum( x, y int ) int { return x + y }
func sub( x, y int ) int { return x - y }

// Higher Order Function
//		Function Which Takes And/Or Return Functions

// Polymorphic Function
//		Using Mechanism By Passing Function/Behaviour To Function/Behaviour

// Function Type
//		(int, int, (int, int) -> int) -> int

func calculator( x, y int, operation func(int, int)int ) int {
	return operation(x, y)
}

func playWithHigherOrderFunctions() {
	var a, b = 40, 10
	var result = 0

	result = calculator( a, b, sum )
	fmt.Println("Result :", result)

	result = calculator( a, b, sub )
	fmt.Println("Result :", result)

	// Closures/Lambdas
	// 		Anonmous Functions
	addClosure := func( x, y int ) int { return x + y }
	subClosure := func( x, y int ) int { return x - y }

	result = calculator( a, b, addClosure )
	fmt.Println("Result :", result)

	result = calculator( a, b, subClosure )
	fmt.Println("Result :", result)

	result = calculator( a, b, func( x, y int ) int { return x + y } )
	fmt.Println("Result :", result)

	result = calculator( a, b, func( x, y int ) int { return x - y } )
	fmt.Println("Result :", result)

	result = calculator( a, b, func( x, y int ) int { 
		return x + y 
	})
	
	fmt.Println("Result :", result)

	result = calculator( a, b, func( x, y int ) int { 
		return x - y 
	})
	fmt.Println("Result :", result)
}

//________________________________________________________________

func doSomething( x int, y int ) int {
	return x + y + 10
}

func doSomethingMore( x int, y int, z int ) int {
	return x + y + z
}

func playWithFunctionTypes() {
	a, b := 100, 200
	result := 0

	// var something int
	var something func(int, int) int
	// cannot use doSomething 
	// (value of type func(x int, y int) int) 
	// as int value in assignment
	something = doSomething
	result = something(a, b)
	fmt.Println("Result : ", result)

	something = doSomethingMore

	// somethingAgain := calculator
	// var somethingAgain int
	// cannot use calculator 
	//	(value of type func(x int, y int, operation func(int, int) int) int) 
	//	as int value in assignment
	var somethingAgain func(int, int, func(int, int) int ) int
	somethingAgain = calculator

	result = somethingAgain(a, b, sum)
	fmt.Println("Result : ", result)
}

//________________________________________________________________

// Higher Order Function
//		Function Which Returns Function

// Function Type
//		() -> (float64) -> float64

func Sphere() func(radius float64) float64 {
	volumeClosure := func( radius float64 ) float64 {
		volume := 4 /3 * math.Pi * radius * radius * radius
		return volume
	}

	return volumeClosure
}

func playWithHigherOrderFunctionsAgain() {
	// What Is The Type Of something
	//	func( float64 ) float64
	something := Sphere()
	//								  Invoking Function				
	fmt.Println("Volume Of Sphere: ", something( 5 ) )
	fmt.Println("Volume Of Sphere: ", something( 10 ) )

	// What Is The Type Of something
	// func() func( float64 ) float64
	somethingAgain := Sphere
	fmt.Println("\nValue Of somethingAgain: ", somethingAgain )
	fmt.Printf("\nType Of somethingAgain: %T", somethingAgain)

	fmt.Println("\nValue Of Sphere: ", Sphere( ) )
	fmt.Printf("\nType Of Sphere: %T", Sphere( ) )

	fmt.Println("\nValue Of Sphere: ", Sphere )
	fmt.Printf("\nType Of Sphere: %T", Sphere )
}

// Value Of somethingAgain:  0x10303ec70
// Type Of somethingAgain: func() func(float64) float64
// Value Of Sphere:  0x10303f120
// Type Of Sphere: func(float64) float64
// Value Of Sphere:  0x10303ec70
// Type Of Sphere: func() func(float64) float64

//________________________________________________________________

func firstFunction() 	{ fmt.Println("First Function Called...") 	}
func secondFunction() 	{ fmt.Println("Second Function Called...") 	}
func thirdFunction() 	{ fmt.Println("Third Function Called...")	}

func playWithDeferFunctions() { // Enclosing Function
	// defer Keyword Delays Execution Of Statement
	//		Till End Of Enclosing Function
	defer firstFunction()
	secondFunction()
	defer thirdFunction()
// defer Statements Are Called Just 
//		Before Return Out Of Enclosing Functions
//		Multiple Defers Are Called Last In First Out Order
}	

//________________________________________________________________

func someFunction() ( some int ) {
	defer func() { some++ }()
	return 1
}

func playWithDeferFunctionsAgain() {
	result := someFunction()
	fmt.Println("Result : ", result)
}

// The behavior of defer statements is straightforward and predictable. 
// There are three simple rules:
// 	1. A deferred function’s arguments are evaluated when 
//		the defer statement is evaluated.
//  2. Deferred function calls are executed in Last In First Out Order 
		// after the surrounding function returns.
// 3. Deferred functions may read and assign to the returning 
// 		function’s named return values.

//______________________________________________________
//______________________________________________________
//______________________________________________________
//______________________________________________________

func main() {
	fmt.Println("\n\nFunction: playWithDivsion")
	playWithDivsion()

	fmt.Println("\n\nFunction: playWithClosures")
	playWithClosures()
	
	fmt.Println("\nFunction: playWithHigherOrderFunctions")
	playWithHigherOrderFunctions()

	fmt.Println("\nFunction: playWithFunctionTypes")
	playWithFunctionTypes()

	fmt.Println("\nFunction: playWithHigherOrderFunctionsAgain")
	playWithHigherOrderFunctionsAgain()

	fmt.Println("\nFunction: playWithDeferFunctions")
	playWithDeferFunctions()

	fmt.Println("\nFunction: playWithDeferFunctionsAgain")
	playWithDeferFunctionsAgain()

	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
}


