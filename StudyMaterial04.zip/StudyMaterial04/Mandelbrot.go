package main

// Data Types In Go Language

// 1. Integer Types
//		Signed int 		: int8, int16, int32, int64
//		Unsigned int 	: uint8, uint16, uint32, unint64

//		int, uint // Platform Dependent as well as Compiler

// 2. Floating Point Types 
//		float32 and float64

//		Why not here are Signed and Unsigned Flavors of Floating Point Data Types like int Type???

// 3. Complex Number Types
//		complex64 And complex128
//			complext64 Have Real and Imaginary Part of float32
//			complext128 Have Real and Imaginary Part of float64


import (
	"image"
	"image/color"
	"image/png"
	"math/cmplx"
	"os"
)

func main() {
	const (
		xmin, ymin, xmax, ymax = -2, -2, +2, +2
		width, height          = 1024, 1024
	)

	img := image.NewRGBA(image.Rect(0, 0, width, height))
	for py := 0; py < height; py++ {
		y := float64(py)/height*(ymax-ymin) + ymin
		for px := 0; px < width; px++ {
			x := float64(px)/width*(xmax-xmin) + xmin
			z := complex(x, y)
			// Image point (px, py) represents complex value z.
			img.Set(px, py, mandelbrot(z))
		}
	}
	png.Encode(os.Stdout, img) // NOTE: ignoring errors
}

func mandelbrot(z complex128) color.Color {
	const iterations = 200
	const contrast = 15

	var v complex128
	for n := uint8(0); n < iterations; n++ {
		v = v*v + z
		if cmplx.Abs(v) > 2 {
			return color.Gray{255 - contrast*n}
		}
	}
	return color.Black
}
