
import java.util.Arrays;

//_____________________________________________________

class HelloDemo {
	public void sayHello() {
		System.out.println("Hello World!!!");
	} 
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________

public class Experiments {
	public static void playWithHelloDemo() {
		HelloDemo demo = new HelloDemo();
		demo.sayHello();
	}

	public static void playWithNumbers() {
		int[] numbers 		= { 10, 20, 30, 40, 50 };
		int[] numbersCopy	= numbers;

		System.out.println("Numbers: " + Arrays.toString( numbers ));
		System.out.println("Numbers: " + Arrays.toString( numbersCopy ));

		numbers[0] = 111;
		numbers[4] = 444;
		System.out.println("Numbers: " + Arrays.toString( numbers ));
		System.out.println("Numbers: " + Arrays.toString( numbersCopy ));
	}

	public static void main( String[] args ) {
		System.out.println("\nFunction: playWithHelloDemo");
		playWithHelloDemo();

		System.out.println("\nFunction: playWithNumbers");
		playWithNumbers();

		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
	}
}

