
package main

import (
	"fmt"
	"math"
)

//________________________________________________________________

type Point struct {
	X, Y float64
}

// Function Taking Two Point Type Arguments
func Distance( p Point, q Point ) float64 {
	return math.Hypot( q.X - p.X , q.Y - p.Y )
}

// Method Taking Two Point Type Arguments
//		Memeber Method/Function Of Type Point
//		Reciever Type Is Point
func ( this Point ) Distance( q Point ) float64 {
	fmt.Println("Point: Distance Method Called...")
	return math.Hypot( q.X - this.X , q.Y - this.Y )
}

func playWithFunctionsAndMethods() {
	var point1 = Point{ 10.0, 20.0 	 }
	var point2 = Point{ 100.0, 200.0 }

	distance := Distance( point1, point2 )
	fmt.Printf("\nDistance Between %v and %v : %v", point1, point2, distance)

	distance = point1.Distance( point2 )
	fmt.Printf("\nDistance Between %v and %v : %v", point1, point2, distance)	
}

//________________________________________________________________

// Receiver Type Point
// ScaleBy Is Member Function On Type Point
func ( point Point ) ScaleByDesign0( factor float64 ) {
	point.X = point.X * factor
	point.Y = point.Y * factor
}

func ( point Point ) ScaleByDesign1( factor float64 )  Point {
	return Point{ point.X * factor, point.Y * factor }
}

func ( point * Point ) ScaleByDesign2( factor float64 ) {
	point.X = point.X * factor
	point.Y = point.Y * factor
}

func playWithScalingPoint() {
	var point1 = Point{ 10.0, 20.0 	}
	var point2 = Point{ 30.0, 40.0 }

	point1.ScaleByDesign0( 5.0 ) 
	point2.ScaleByDesign0( 10.0 ) 

	fmt.Println("Scaled Point: ", point1 )
	fmt.Println("Scaled Point: ", point2 )	

	var point10 = Point{ 10.0, 20.0 }
	var point20 = Point{ 30.0, 40.0 }

	point10 = point10.ScaleByDesign1( 5.0 ) 
	point20 = point20.ScaleByDesign1( 10.0 ) 

	fmt.Println("Scaled Point: ", point10 )
	fmt.Println("Scaled Point: ", point20 )	

	var point11 = Point{ 10.0, 20.0 }
	var point21 = Point{ 30.0, 40.0 }

	point11.ScaleByDesign2( 5.0 ) 
	point21.ScaleByDesign2( 10.0 ) 

	fmt.Println("Scaled Point: ", point11 )
	fmt.Println("Scaled Point: ", point21 )	
}

// Function: playWithScalingPoint
// Scaled Point:  {10 20}
// Scaled Point:  {30 40}

//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________

func main() {
	fmt.Println("\nFunction: playWithFunctionsAndMethods")
	playWithFunctionsAndMethods()

	fmt.Println("\nFunction: playWithScalingPoint")
	playWithScalingPoint()
	
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")	
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")	
}



