/*
1. Save Following Code in Hello.go
2. Run Go Code Directly
	go run Hello.go
3. Build Go Code and Run
	go build Hello.go
	./Hello
*/

package main

import "fmt"
import "os"

//______________________________________________________

func helloWorld() {
	fmt.Println("Hello World!!!")
}

//______________________________________________________

const boilingF = 212.0
var ff = 99
var cc = 88

// var dd
var dd1 int
var dd2 = 99

func fToC(f float64) float64 {
	return ( f - 32 ) * 5 / 9 
}

func playWithConstantAndVariables() {
	var f = boilingF
	var c = ( f - 32 ) * 5 / 9

	fmt.Printf("\nBoiling Point: %g Farenheit", f )
	fmt.Printf("\nBoiling Point: %g Centigrade", c )

	var boilingC = fToC( boilingF )
	fmt.Printf("\nBoiling Point: %g Centigrade", boilingC )

	const first, second = 99.99, 88.88
	fmt.Printf("\nFirst: %g, Second: %g", first, second)
}

//______________________________________________________

type Celsius  	  float64
type Fahrenheit   float64

// Code 01
// const BoilingC  			Celsius 	= 100.0
// const FreezingC 			Celsius 	= 0.0
// const AbosulteZeroC 		Celsius 	= -273.15
// const FreezingF 			Fahrenheit 	= 0.05

// Code 02
const (
	BoilingC  			Celsius 	= 100.0
	FreezingC 			Celsius 	= 0.0
	AbosulteZeroC 		Celsius 	= -273.15
	FreezingF 			Fahrenheit 	= 0.05
)

// Above Code 01 and Code 02 Are Equivalent

func playWithTypes() {
	// Code 03
	// var ff = 11.11
	// var gg = 22.22

	// Code 03
	// var ff float64 = 11.11
	// var gg float64 = 22.22

	// Code 05
	var ff, gg = 11.11, 22.22

// Above Code 03, Code 04 and Code 04 Are Equivalent

	var rr = ff + gg
	fmt.Println("Result: ", rr )

	var ffAgain Celsius 	= 11.11
	var ggAgain Fahrenheit 	= 22.22
	fmt.Println("Values Again: ", ffAgain, ggAgain )
	// ./GoFoundation.go:91:16: invalid operation: 
	// 		ffAgain + ggAgain (mismatched types Celsius and Fahrenheit)
	// var rrAgain = ffAgain + ggAgain

	var rrAgain = float64( ffAgain ) + float64( ggAgain )
	fmt.Println("Result: ", rrAgain )

	var someInt int64  = 3
	var someFloat float64 = 90.90
	fmt.Println( someInt )
	fmt.Println( someFloat )

	// ./GoFoundation.go:99:18: invalid operation: 
	//		someInt + someFloat (mismatched types int64 and float64)
	// var something = someInt + someFloat

	var something = float64( someInt ) + someFloat
	fmt.Println( something )

	var something1 = someInt + int64( someFloat )
	fmt.Println( something1 )
}

//______________________________________________________

func FToC( f Fahrenheit ) Celsius {
	return Celsius( ( f - 32 ) * 5 / 9 )
}

func CToF( c Celsius ) Fahrenheit {
	return Fahrenheit( c * 9 / 5 + 32 )
}

func playWithTypesAgain() {
	var result = FToC( FreezingF )
	fmt.Println("Result : ", result )

	var resultAgain = CToF( FreezingC )	
	fmt.Println("resultAgain : ", resultAgain )

	var resultOnceAgain = FToC( 212.15 )
	fmt.Println( resultOnceAgain )
}

//______________________________________________________

// import "os"

func playWithCommandLineArguments() {
	var someString, seperator string 	
	// var someString string, seperator string 	

	seperator = "\n"
	var args = os.Args
	
	for i := 0 ; i < len( args ) ; i++ {
		// someString =  someString + seperator + args[i]
		fmt.Printf("\n At %d Value: %s", i, args[i] )	
	}

	fmt.Println( someString )
	fmt.Println( seperator )

}

//__________________________________________________________

func playWithTypesAndDefaultValues() {
	// Following Types Are Initialised To Default Values Of 0
	var a int 
	var a8 int8
	var a16 int16
	var a32 int32
	var a64 int64

	aa := 99
	fmt.Println("Value Of aa: ", aa )
	fmt.Printf("Type Of aa: %T \n", aa )

	var ua uint 
	var ua8 uint8
	var ua16 uint16
	var ua32 uint32
	var ua64 uint64

	fmt.Println(a, a8, a16, a32, a64)
	fmt.Println(ua, ua8, ua16, ua32, ua64)

	var f1 float32
	var f2 float64
	fmt.Println( f1, f2 )

	ff := 99.90
	fmt.Println("Value Of ff: ", ff)
	fmt.Printf("Type Of ff: %T \n", ff)

	var some string
	fmt.Println( some )

	greeting := "Good Morning!"
	fmt.Println("Value Of greeting: ", greeting)
	fmt.Printf("Type Of greeting: %T \n", greeting)

	var b bool
	fmt.Println( b )

	var c1 complex64
	fmt.Println( c1 )

	var c2 complex128
	fmt.Println( c2 )
}
	
//______________________________________________________

func infiniteFunction() {
	for {
		fmt.Printf(".")
	}	
}

//______________________________________________________
//______________________________________________________
//______________________________________________________

func main() {
	fmt.Println("\n\nFunction: helloWorld")
	// some := helloWorld()
	helloWorld()

	fmt.Println("\n\nFunction: playWithConstantAndVariables")
	playWithConstantAndVariables()

	fmt.Println("\n\nFunction: playWithTypes")
	playWithTypes()

	fmt.Println("\n\nFunction: playWithTypesAgain")
	playWithTypesAgain()

	fmt.Println("\n\nFunction: playWithCommandLineArguments")
	playWithCommandLineArguments()

	fmt.Println("\n\nFunction: playWithTypesAndDefaultValues")
	playWithTypesAndDefaultValues()

	fmt.Println("\n\nFunction: infiniteFunction")
	infiniteFunction()
	
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
}

