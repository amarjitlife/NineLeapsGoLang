
/*
1. Save Following Code in Hello.go

2. Run Go Code Directly
	go run Hello.go

3. Build Go Code and Run
	go build Hello.go
	./Hello
*/

package main

import "fmt"

func main() {
	fmt.Println("Hello World!!!")
}

