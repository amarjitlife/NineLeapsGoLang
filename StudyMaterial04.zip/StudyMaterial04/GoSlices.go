
package main

import "fmt"

//______________________________________________________

func playWithArrayAndSlices() {
	// var a [10]int = [10]int{10, 20, 30, 40, 50, 60, 70, 80, 90, 99}
	// a  := [...]int{10, 20, 30, 40, 50, 60, 70, 80, 90, 99}
	a  := [10]int{10, 20, 30, 40, 50, 60, 70, 80, 90, 99}

	// Above 3 Lines of Code Are Equivalent

	fmt.Println("Array : ", a)
	fmt.Printf("Array Len: %d\n", len( a ) )
	fmt.Printf("Array Type: %T\n", a)

	some1 := a[ 0 : 4 ]
	fmt.Println("Slice a[ 0 : 4 ]: ", some1 )

	some2 := a[ 4 : 9 ]
	fmt.Println("Slice a[ 4 : 9 ]: ", some2 )

	some3 := a[ : 5 ]
	fmt.Println("Slice a[  : 5 ]: ", some3 )

	some4 := a[ 6 :  ]
	fmt.Println("Slice a[ 6 : 0 ]: ", some4 )

	some5 := a[ : ]  // Default To [ 0 : len ]
	fmt.Println("Slice a[ : ]: ", some5 )

	some1[0] = 11
	fmt.Println("Slice a[ 0 : 4 ]: ", some1 )
	fmt.Println("Array : ", a)	

	fmt.Printf("Array Type: %T\n", a)
	fmt.Printf("Slice Type: %T\n", some1)
	fmt.Printf("Slice Type: %T\n", some2)
}

// Function: playWithArrayAndSlices
// Array :  [10 20 30 40 50 60 70 80 90 99]
// Array Len: 10
// Array Type: [10]int
// Slice a[ 0 : 4 ]:  [10 20 30 40]
// Slice a[ 4 : 9 ]:  [50 60 70 80 90]
// Slice a[  : 5 ]:   [10 20 30 40 50]
// Slice a[ 6 :  ]:   [70 80 90 99]
// Slice a[ : ]:  	   [10 20 30 40 50 60 70 80 90 99]

//__________________________________________________________

// Function Taking Slice As Argument
func reverse( s []int ) {
	for i, j := 0, len( s ) - 1 ; i < j ; i, j = i + 1, j - 1 {
		s[i], s[j] = s[j], s[i]
	}
}

func playWithArrayAndSlicesAgain() {
	a := [...]int{ 10, 20, 30, 40, 50, 60, 70, 80, 90, 99 }
	fmt.Println("Array a: ", a)

	some1 := a[ 0 : 4 ]
	fmt.Println("Array a: ", a )	
	reverse( some1 )
	fmt.Println("Array a: ", a )

	some2 := a[ 4 : 9 ]
	fmt.Println("Array a: ", a )	
	reverse( some2 )
	fmt.Println("Array a: ", a )

	some3 := a[ : ]
	fmt.Println("Array a: ", a )	
	reverse( some3 )
	fmt.Println("Array a: ", a )
}

// Function: playWithArrayAndSlicesAgain
// Array a:  [10 20 30 40 50 60 70 80 90 99]
// Array a:  [10 20 30 40 50 60 70 80 90 99]
// Array a:  [40 30 20 10 50 60 70 80 90 99]
// Array a:  [40 30 20 10 50 60 70 80 90 99]
// Array a:  [40 30 20 10 90 80 70 60 50 99]

/*
	some5 := a[ : ]
	fmt.Println("Array a: ", a )	
	doSomething( some5 )
	fmt.Println("Array a: ", a )
*/

//__________________________________________________________

// Function Taking 2 Slices As Argument
func printCommon( summer []string, quater []string ) {
	for _, summerMonth := range summer {
		for _, quaterMonth := range quater {
			if summerMonth == quaterMonth {
				fmt.Printf("%s Month Appear In Both!", summerMonth)
			}
		}
	}
}

// Following Both Signatures Are Equivalent
// func slicesEqual( x []string, y []string ) bool {
func slicesEqual( x, y []string ) bool {
	if len( x ) != len( y ) {
		return false 
	}

	for index := range x {
		if x[index] != y[index] {
			return false
		}
	}

	return true
}

func playWithArrayAndSlicesOnceAgain() {
	months := [...]string {
		1: "January", 2: "February", 3: "March", 4: "April",
		5: "May", 6: "June", 7: "July", 8: "August",
		9: "September", 10: "October", 11: "November", 12: "December",
	}

	quater2 := months[ 4 : 7] 
	summer := months[ 6 : 9 ]
	fmt.Println( months )
	fmt.Println( quater2 )
	fmt.Println( summer )
	printCommon( summer, quater2 )

	firstThree := months[ 1 : 4   ]
	quater1 := months[ 1 : 4 ]

	// invalid operation: firstThree == quater1 (slice can only be compared to nil)
	// fmt.Println("Slices Are Equal: ", firstThree == quater1 ) 
	result := slicesEqual( firstThree, quater1 )
	fmt.Println("Slices Are Equal: ", result ) 
}


//________________________________________________________________
//
// 				GO SLICES CONCEPTS
//________________________________________________________________

// Slices represent variable-length sequences whose elements all have 
//		the same type. 
// 	A slice type is written []T, where the elements have type T; 
// 		it looks like an array type without a size.

// A slice is a lightweight data structure that gives access to 
//	a subsequence (or perhaps all) of the elements of an array, 
//	which is known as the slice’s underlying array. 

// 	A slice has three components: a pointer, a length, and a capacity. 
// 		The pointer points to the first element of the array that is 
//          reachable through the slice, which is not necessarily 
//			the array’s first element. 
// 		The length is the number of slice elements; it can’t exceed 
//			the capacity, which is usually the number of elements between 
// 			the start of the slice and the end of the underlying array. 
// 		The built-in functions len and cap return those values.

// The slice operator s[ i : j ], where 0 ≤ i ≤ j ≤ cap(s), 
// 	Creates a new slice that refers to elements i through j-1 of the 
//	sequence s, which may be an array variable, a pointer to an array, 
//	or anotherslice. The resulting slice has j-i elements. 
// 	If i is omitted,it’s 0,and if j isomitted, it’s len(s). 

// 	Thus the slice months[1:13] refers to the whole range of valid 
//	months, as does the slice months[1:]; the slice months[:] refers 
//	to the whole array.

//______________________________________________________

func playWithSlicesLengthAndCapacity() {

	// The built-in function make creates a slice of a specified element type, 
	// length, and capacity. The capacity argument may be omitted, 
	// in which case the capacity equals the length.
	// 		make([]T, len)
	// 		make([]T, len, cap) // same as make([]T, cap)[:len]

	s := make( []string, 3 )
	fmt.Printf("Slice Type: %T\n", s)
	fmt.Println("Slice     :", s)
	fmt.Printf("Slice Length: %d  Capacity : %d\n", len( s ), cap( s ) )

	s[0] = "Ding"
	fmt.Println("Slice     :", s)
	fmt.Printf("Slice Length: %d  Capacity : %d\n", len( s ), cap( s ) )

	s[1] = "Dong"
	fmt.Println("Slice     :", s)
	fmt.Printf("Slice Length: %d  Capacity : %d\n", len( s ), cap( s ) )

	s[2] = "Ting"
	fmt.Println("Slice     :", s)
	fmt.Printf("Slice Length: %d  Capacity : %d\n", len( s ), cap( s ) )

	// s[3] = "Tong"
	// fmt.Println("Slice     :", s)
	// fmt.Printf("Slice Length: %d  Capacity : %d\n", len( s ), cap( s ) )

	s = append( s, "Tong" )
	fmt.Println("Slice     :", s)
	fmt.Printf("Slice Length: %d  Capacity : %d\n", len( s ), cap( s ) )	

	s = append( s, "Ming" )
	fmt.Println("Slice     :", s)
	fmt.Printf("Slice Length: %d  Capacity : %d\n", len( s ), cap( s ) )	

	s = append( s, "Mong" )
	fmt.Println("Slice     :", s)
	fmt.Printf("Slice Length: %d  Capacity : %d\n", len( s ), cap( s ) )	

	s = append( s, "Gabbar Singh" )
	fmt.Println("Slice     :", s)
	fmt.Printf("Slice Length: %d  Capacity : %d\n", len( s ), cap( s ) )	

	// s[7] = "Thakur"
	// fmt.Println("Slice     :", s)
	// fmt.Printf("Slice Length: %d  Capacity : %d\n", len( s ), cap( s ) )	
}

//__________________________________________________________

// In C/C++/Java
// 		Arrays Are Reference Type

// In Go
// 		Arrays Are Value Type
// 		Slices Are Reference Type

func playWithArrayAndSlicesConcepts() {
	numbers := [...]int{ 10, 20, 30, 40, 50, 60, 70, 80, 90, 99 }

	numbersCopy := numbers  // Value Assignment 

	fmt.Println(" Numbers Length Capacity: ", len( numbers ), cap( numbers ) )
	fmt.Println(" NumbersCopy Length Capacity: ", len( numbersCopy ), cap( numbersCopy ) )

	fmt.Println( "Numbers: ", numbers )
	fmt.Println( "NumbersCopy: ", numbersCopy )

	numbers[ 0 ] = 99
	fmt.Println( "Numbers: ", numbers )
	fmt.Println( "NumbersCopy: ", numbersCopy )

	some := numbers[ 0 : 3 ]
	fmt.Println( "Some: ", some )
	fmt.Println(" Some Length Capacity: ", len( some ), cap( some ) )

	some = append( some, 77 )
	fmt.Println( "Some: ", some )
	fmt.Println(" Some Length Capacity: ", len( some ), cap( some ) )
	fmt.Println( "Numbers: ", numbers )
	fmt.Println(" Numbers Length Capacity: ", len( numbers ), cap( numbers ) )

	// Shallow Copy
	someCopy := some // Reference Type
	fmt.Println( "Some   : ", some )
	fmt.Println( "SomeCopy   : ", someCopy )
	
	some[0] = 777
	fmt.Println( "Some   : ", some )
	fmt.Println( "SomeCopy   : ", someCopy )
	fmt.Println( "Numbers: ", numbers )
	fmt.Println(" Numbers Length Capacity: ", len( numbers ), cap( numbers ) )

	//__________________________________________

	ss := make( []int, 4 )

	fmt.Println( "SS: ", ss )
	fmt.Println(" SS Length Capacity: ", len( ss ), cap( ss ) )

	ss[0] = 10
	ss[1] = 20
	ss[2] = 30
	ss[3] = 40
	fmt.Println( "SS: ", ss )

	cc := make( []int, len(ss) )
	fmt.Println( "SS: ", ss )
	fmt.Println( "CC: ", cc )
	fmt.Println(" CC Length Capacity: ", len( cc ), cap( cc ) )

	cc = ss
	fmt.Println( "SS: ", ss )
	fmt.Println( "CC: ", cc )
	fmt.Println(" CC Length Capacity: ", len( cc ), cap( cc ) )

	ss[3] = 777
	fmt.Println( "SS: ", ss )
	fmt.Println( "CC: ", cc )
	fmt.Println(" SS Length Capacity: ", len( ss ), cap( ss ) )
	fmt.Println(" CC Length Capacity: ", len( cc ), cap( cc ) )

	dd := make( []int, len(ss) )

	// Deep Copy: Full Object Copied
	copy( dd, ss )
	fmt.Println( "SS: ", ss )
	fmt.Println( "DD: ", dd )
	fmt.Println(" SS Length Capacity: ", len( ss ), cap( ss ) )
	fmt.Println(" DD Length Capacity: ", len( dd ), cap( dd ) )

	ss[1] = 999
	fmt.Println( "SS: ", ss )
	fmt.Println( "DD: ", dd )
	fmt.Println(" SS Length Capacity: ", len( ss ), cap( ss ) )
	fmt.Println(" DD Length Capacity: ", len( dd ), cap( dd ) )	
}

//__________________________________________________________

func appendInt( x []int, y int ) []int {
	var z []int

	zlen := len( x ) + 1
	if zlen <= cap(x) {
		z = x[ : zlen ]
	} else {
		zcap := zlen
		if zcap < 2 * len( x ) {
			zcap = 2 * len( x )
		}

		z = make( []int, zlen, zcap )
		copy( z, x )
	}

	z[ len( x )] = y
	return z
}

func playWithAppendInt() {
	var x, y []int

	for i := 0 ; i < 10 ; i++ {
		y = appendInt( x, i )
		fmt.Printf(" %d Capacity = %d \t %v \n", i, cap(y), y )
		x = y
	}
}


//__________________________________________________________
// Polymorphic Function
//		Using Varidiac Function

// Varidiac Function
//		Function With Variable Number Of Arguments
func summation( numbers ...int ) int {
	// fmt.Print( numbers )
	total := 0

	for _, number := range numbers {
		total = total + number
	}

	return total
}

func playWithSummation() {
	var result int

	result = summation()
	fmt.Println("Result : ", result )

	result = summation(11)
	fmt.Println("Result : ", result )

	result = summation(10, 20, 30, 40, 50)
	fmt.Println("Result : ", result )

	result = summation(10, 20, 30, 40, 50, 60, 80, 90)
	fmt.Println("Result : ", result )

	numbers := []int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
	result = summation( numbers... )
	fmt.Println("Result : ", result )	
}


//__________________________________________________________


func appendSlice( x []int, y ...int ) [] int {
	var z []int

	zlen := len(x) + len(y)

	if zlen <= cap(x) {
		z = x[ : zlen ]
	} else {
		zcap := zlen
		if zcap < 2 * len(x) {
			zcap = 2 * len(x)
		}
		z = make( []int, zlen, zcap )
		copy(z, x)
	}
	copy( z[ len(x) : ], y )
	return z
}

func playWithAppendSlices() {
	var x, y []int

	for i := 0 ; i < 10 ; i++ {
		y = appendSlice(x, i)
		fmt.Printf( " %d Capacity=%d \t %v \n", i, cap(y), y )
		x = y
	}
	fmt.Println( x )

	x = appendSlice(x, 10, 20, 30)
	fmt.Println( x )

	x = appendSlice(x, 11, 22, 33, 44, 55, 66)
	fmt.Println( x )

	numbers := []int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
	x = appendSlice(x, numbers...)
	fmt.Println( x )	
}


//______________________________________________________

func playWithSomething() {
	something := make( [][]int, 3 )

	for i := 0 ; i < 3 ; i++ {
		innerLen := i + 1

		something[i] = make( []int, innerLen )

		for j := 0 ; j < innerLen ; j++ {
			something[i][j] = i + j
		}
	}

	fmt.Println( something )
}

//______________________________________________________
//______________________________________________________
//______________________________________________________

func main() {
	fmt.Println("\n\nFunction: playWithArrayAndSlices")
	playWithArrayAndSlices()

	fmt.Println("\nFunction: playWithArrayAndSlicesAgain")
	playWithArrayAndSlicesAgain()

	fmt.Println("\nFunction: playWithArrayAndSlicesOnceAgain")
	playWithArrayAndSlicesOnceAgain()

	fmt.Println("\n\nFunction: playWithSlicesLengthAndCapacity")
	playWithSlicesLengthAndCapacity()

	fmt.Println("\n\nFunction: playWithArrayAndSlicesConcepts")
	playWithArrayAndSlicesConcepts()

	fmt.Println("\n\nFunction: playWithAppendInt")
	playWithAppendInt()

	fmt.Println("\n\nFunction: playWithSummation")
	playWithSummation()

	fmt.Println("\n\nFunction: playWithAppendSlices")
	playWithAppendSlices()

	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
}



