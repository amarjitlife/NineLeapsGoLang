
_____________________________________________________________

Installing Go Compiler
_____________________________________________________________

	1. Download Go Compiler
		
		go1.26.5.linux-amd64.tar.gz	

	2. Copy go1.26.5.linux-amd64.tar.gz	 File in  ~/Documents/Softwares/Compilers

		cp ~/Download/go1.26.5.linux-amd64.tar.gz ~/Documents/Softwares/Compilers/

	3. Extract Tar Ball
		
		tar -xvzf go1.26.5.darwin-arm64.tar.gz

	4. Export PATH Variable

		export PATH=$PATH:/Users/intelligene/Documents/Softwares/Compilers/go/bin

	5. Check Go Compiler
		
		go version

_____________________________________________________________
_____________________________________________________________

https://codeshare.io/29qxPK
https://codeshare.io/29qxPK
https://codeshare.io/29qxPK

_____________________________________________________________
_____________________________________________________________

https://github.com/amarjitlife/NineLeapsGoLang
https://github.com/amarjitlife/NineLeapsGoLang
https://github.com/amarjitlife/NineLeapsGoLang

_____________________________________________________________
_____________________________________________________________

https://tinyurl.com/5h5uy7nb
https://tinyurl.com/5h5uy7nb
https://tinyurl.com/5h5uy7nb

_____________________________________________________________
_____________________________________________________________




