
#include <stdio.h>

//__________________________________________________

void playWithArrays() {
	int numbers[5] = { 10, 20, 30, 40, 50 };

	printf("\nValue : %d", numbers[0]);
	printf("\nValue : %d", numbers[1]);
	printf("\nValue : %d", numbers[2]);

	for ( int i = -10 ; i < 10 ; i++ ) {
		printf("\nValue : %d", numbers[i] );
	}
}


//__________________________________________________

void playWithTypeCint() {
	int a = 66536;
	// int a = 2147483647;
	int b = 22;

	int c = a + b;
	printf("\nResult: %d", c);
}

// Function: playWithTypeCint
// Result: -2147483627

// Expected:
//		Result: 2147483669

//__________________________________________________

void printArray( int numbers[], int size ) {
	printf("\n");
	for ( int i = 0 ; i < size ; i++ ) {
		printf(" %d, ", numbers[i] );
	}
}

void doChangeArray( int numbers[], int size ) {
	for ( int i = 0 ; i < size ; i++ ) {
		numbers[i] = 99 ;
	}
}

void doChangeArrayAgain( int * numbers, int size ) {
	for ( int i = 0 ; i < size ; i++ ) {
		numbers[i] = 77 ;
	}
}

void playWithChangeArrays() {
	int numbers[5] = { 10, 20, 30, 40, 50 };

	printArray( numbers, 5 );
	doChangeArray( numbers, 5 );
	printArray( numbers, 5 );

	doChangeArrayAgain( numbers, 5 );
	printArray( numbers, 5 );
}
	

//__________________________________________________
//__________________________________________________

int main() {
	printf("\n\nFunction: playWithArrays");
	playWithArrays();

	printf("\n\nFunction: playWithTypeCint");
	playWithTypeCint();

	printf("\n\nFunction: playWithChangeArrays");
	playWithChangeArrays();

//	printf("\n\nFunction: ");
//	printf("\n\nFunction: ");
//	printf("\n\nFunction: ");
//	printf("\n\nFunction: ");
//	printf("\n\nFunction: ");
//	printf("\n\nFunction: ");
	return 0;
}


