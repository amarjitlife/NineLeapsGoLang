

_____________________________________________________________________

DAY 01
_____________________________________________________________________

	Assignment A0: Practice and Extend Go Code and Questions
		1. Code Examples Done In Class
		2. Solve Questions Given In Class

	Assignment A1: Reading, Coding and Practice Assignment
		Book: The C Programming Language, 2nd Edition
				By Brian Kernigham and Dennish Richie

			Read, Practice and Reason Following Chapter 
				Chapter 02: Types, Operations and Expressions
				Chapter 05: Pointers and Arrays

	Assignment A2: Reading, Coding and Practice Assignment
		Book: The Go Programming Language, Wiley Publication
				By Brian Kernigham and Alan Donovan

			Read, Practice and Reason Following Chapter 
				Chapter 02: Program Structures
				Chapter 03: Basic Data Types

_____________________________________________________________________

DAY 02
_____________________________________________________________________

	Assignment A0: Practice and Extend Go Code and Questions
		1. Code Examples Done In Class
		2. Solve Questions Given In Class

	Assignment A1: Reading, Coding and Practice Assignment
		Book: The C Programming Language, 2nd Edition
				By Brian Kernigham and Dennish Richie

			Read, Practice and Reason Following Chapter 
				Chapter 05: Pointers and Arrays [ MUST MUST ]

	Assignment A2: Reading, Coding and Practice Assignment
		Book: The Go Programming Language, Wiley Publication
				By Brian Kernigham and Alan Donovan

			Read, Practice and Reason Following Chapter 
				Chapter 02: Program Structures
				Chapter 03: Basic Data Types
				Chapter 04: Composite Types
							04.1 Arrays

_____________________________________________________________________

DAY 03
_____________________________________________________________________

_____________________________________________________________________

DAY 04
_____________________________________________________________________

_____________________________________________________________________

DAY 05
_____________________________________________________________________


