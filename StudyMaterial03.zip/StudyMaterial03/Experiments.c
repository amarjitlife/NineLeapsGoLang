
#include <stdio.h>

//__________________________________________________

void playWithArrays() {
	int numbers[5] = { 10, 20, 30, 40, 50 };

	printf("\nValue : %d", numbers[0]);
	printf("\nValue : %d", numbers[1]);
	printf("\nValue : %d", numbers[2]);

	for ( int i = -10 ; i < 10 ; i++ ) {
		printf("\nValue : %d", numbers[i] );
	}
}


//__________________________________________________

void playWithTypeCint() {
	int a = 66536;
	// int a = 2147483647;
	int b = 22;

	int c = a + b;
	printf("\nResult: %d", c);
}

// Function: playWithTypeCint
// Result: -2147483627

// Expected:
//		Result: 2147483669

//__________________________________________________

void printArray( int numbers[], int size ) {
	printf("\n");
	for ( int i = 0 ; i < size ; i++ ) {
		printf(" %d, ", numbers[i] );
	}
}

void doChangeArray( int numbers[], int size ) {
	for ( int i = 0 ; i < size ; i++ ) {
		numbers[i] = 99 ;
	}
}

void doChangeArrayAgain( int * numbers, int size ) {
	for ( int i = 0 ; i < size ; i++ ) {
		numbers[i] = 77 ;
	}
}

void playWithChangeArrays() {
	int numbers[5] = { 10, 20, 30, 40, 50 };

	printArray( numbers, 5 );
	doChangeArray( numbers, 5 );
	printArray( numbers, 5 );

	doChangeArrayAgain( numbers, 5 );
	printArray( numbers, 5 );
}
	

//__________________________________________________

void playWithArraysAgain() {
	int size = 5;
	int numbers[5] = { 10, 20, 30, 40, 50 };
	int * pointer = numbers;

	printf("\nValue : %d", numbers[0]);
	printf("\nValue : %d", numbers[1]);
	printf("\nValue : %d", numbers[2]);

	printf("\nValue : %d", pointer[0]);
	printf("\nValue : %d", pointer[1]);
	printf("\nValue : %d", pointer[2]);

	printf("\nValue : %d", *( pointer + 0 ) );
	printf("\nValue : %d", *( pointer + 1 ) );
	printf("\nValue : %d", *( pointer + 2 ) );

	for ( int i = 0 ; i < size ; i++ ) {
		printf("\nValue : %d", numbers[i] );
	}

	for ( int i = 0 ; i < size ; i++ ) {
		printf("\nValue : %d", pointer[i] );
	}

	for ( int i = 0 ; i < size ; i++ ) {
		printf("\nValue : %d", * ( pointer + i ) );
	}

	printf("\nAddress : %p", numbers + 0 );
	printf("\nAddress : %p", numbers + 1 );
	printf("\nAddress : %p", numbers + 2 );

	printf("\nAddress : %p", pointer + 0 );
	printf("\nAddress : %p", pointer + 1 );
	printf("\nAddress : %p", pointer + 2 );
}

//__________________________________________________

void playWithArraysOnceAgain() {
	int len = 10;

// Array :  [10 20 30 40 50 60 70 80 90 99]
	int numbers[10] = { 10, 20, 30, 40, 50, 60, 70, 80, 90, 99 };
	int * pointer = numbers;

	printf("\n");
// Slice a[ 0 : 4 ]:  [10 20 30 40]
	for ( int i = 0 ; i < 4 ; i++ ) {
		printf(" %d ", numbers[i] );
	}
//  10  20  30  40 

	printf("\n");
// Slice a[ 4 : 9 ]:  [50 60 70 80 90]
	for ( int i = 4 ; i < 9 ; i++ ) {
		printf(" %d ", pointer[i] );
	}
//  50  60  70  80  90 

	printf("\n");
// Slice a[  : 5 ]:   [10 20 30 40 50]
	for ( int i = 0 ; i < 5 ; i++ ) {
		printf(" %d ", * ( pointer + i ) );
	}
//  10  20  30  40  50 

	printf("\n");
// Slice a[ 6 :  ]:   [70 80 90 99]
	for ( int i = 6 ; i < len ; i++ ) {
		printf(" %d ", * ( pointer + i ) );
	}
//  70  80  90  99 

	printf("\n");
// Slice a[ : ]:  	   [10 20 30 40 50 60 70 80 90 99]
	for ( int i = 0 ; i < len ; i++ ) {
		printf(" %d ", * ( pointer + i ) );
	}
//  10  20  30  40  50  60  70  80  90  99
}

// Function: playWithArraysOnceAgain
// Function: playWithArrayAndSlices


//__________________________________________________

void playWithArraysMore() {
	int len = 10;

// Array :  [10 20 30 40 50 60 70 80 90 99]
	int numbers[10] = { 10, 20, 30, 40, 50, 60, 70, 80, 90, 99 };
	int * pointer = numbers;

	for ( int i = -5 ; i < 4 ; i++ ) {
		printf(" %d ", numbers[i] );
	}

	printf("\n");
	for ( int i = -4 ; i < 20 ; i++ ) {
		printf(" %d ", pointer[i] );
	}

	printf("\n");
	for ( int i = -10 ; i < 20 ; i++ ) {
		printf(" %d ", * ( pointer + i ) );
	}
}

//__________________________________________________
//__________________________________________________
//__________________________________________________

int main() {
	printf("\n\nFunction: playWithArrays");
	playWithArrays();

	printf("\n\nFunction: playWithTypeCint");
	playWithTypeCint();

	printf("\n\nFunction: playWithChangeArrays");
	playWithChangeArrays();

	printf("\n\nFunction: playWithArraysAgain");
	playWithArraysAgain();

	printf("\n\nFunction: playWithArraysOnceAgain");
	playWithArraysOnceAgain();

	printf("\n\nFunction: playWithArraysMore");
	playWithArraysMore();
	
//	printf("\n\nFunction: ");
//	printf("\n\nFunction: ");
//	printf("\n\nFunction: ");
	return 0;
}


