
package main

import "fmt"


//______________________________________________________

func division( dividend int, divisor int) (int, int) {
	if divisor != 0 {
		quotient 	:= dividend / divisor
		remainder 	:= dividend % divisor

		return quotient, remainder
	} else {
		fmt.Println("Error: Division By Zero!")
	}
	return 0, -1
}

func divisionAgain( dividend, divisor int) (int, int) {
	if divisor != 0 {
		quotient 	:= dividend / divisor
		remainder 	:= dividend % divisor

		return quotient, remainder
	} else {
		fmt.Println("Error: Division By Zero!")
	}
	return 0, -1
}

func divisionOnceAgain( dividend, divisor int) (quotient, remainder int) {
	if divisor != 0 {
		quotient 	:= dividend / divisor
		remainder 	:= dividend % divisor

		return quotient, remainder
	} else {
		fmt.Println("Error: Division By Zero!")
	}
	return 0, -1
}

func playWithDivsion() {
	q, r := division( 10, 3 )
	fmt.Printf("\nQuotient: %d Remainder: %d", q, r )

	qq, rr := divisionAgain( 10, 3 )
	fmt.Printf("\nQuotient: %d Remainder: %d", qq, rr )

	qqq, rrr := divisionOnceAgain( 10, 3 )
	fmt.Printf("\nQuotient: %d Remainder: %d", qqq, rrr )

}

//______________________________________________________
//______________________________________________________
//______________________________________________________
//______________________________________________________
//______________________________________________________
//______________________________________________________

func main() {
	fmt.Println("\n\nFunction: playWithDivsion")
	playWithDivsion()

	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
}


