
package main

import "fmt"

//__________________________________________________________

func playWithArrays() {
	var a[4]int 

	fmt.Println( a )
	// range Operator Gives
	//		List of Tuples Having 2 Members
	//		First Member Will Be Index
	//		Second Member Will Be Value
	for i, value := range a {
		fmt.Println( i, value )
	}

	fmt.Println( a[0] )
	fmt.Println( a[1] )
	fmt.Println( a[ len( a ) - 1 ] )
	// invalid argument: index 4 out of bounds [0:4]
	// fmt.Println( a[ len( a ) ] )	

	// _ Is A Special Variable
	//		Used For Ignoring i.e. Which You Don't Wants To Use
	for _, value := range a {
		fmt.Println( value )
	}

	for index := range a {
		fmt.Println( index, a[ index ] )
	}

	var numbers [5]int = [5]int{ 10, 20, 30, 40, 50 }
	fmt.Println( numbers[0] )
	fmt.Println( numbers[1] )
// 	fmt.Println( numbers[5] )
// 	fmt.Println( numbers[-1] )
}

//______________________________________________________


func playWithArraysAgain() {
	var q [5]int = [5]int{ 10, 20, 30, 40, 50 }
	var r [5]int = [5]int{ 10, 20, 30 }

	fmt.Println("Array Length q: ", len( q ) )
	fmt.Println("Array Length r: ", len( r ) )
	fmt.Printf("Array q Type: %T \n", q )
	fmt.Printf("Array r Type: %T \n", r )

	for index, value := range q {
		fmt.Println("At Index: ", index, " Value: ", value)
	}

	for index, value := range r {
		fmt.Println("At Index: ", index, " Value: ", value)
	}

	// ... Dots Means Size Deduced From Initialisation List
	//			  // Initialisation List
	s := [...]int{10, 20, 30, 99, 100, 111}
	// Above Line Compiler Will Convert To Following
	// var s [6]int = [6]int{10, 20, 30, 99, 100, 111}
	fmt.Println("Array s: ", s )
	fmt.Println("Array Length s: ", len( s ) )
	fmt.Printf("Array s Type: %T \n ", s )

	for index, value := range s {
		fmt.Println("At Index: ", index, " Value: ", value )
	}


	aa := [2]int { 10, 20 }
	bb := [...]int { 10, 20 }
	cc := [2]int { 10, 20 }

	fmt.Println("aa Equals bb : ", aa == bb)
	fmt.Println("aa Equals cc : ", aa == cc)
	fmt.Println("cc Equals bb : ", cc == bb)

	aaa := [2]int { 10, 20 }
	bbb := [3]int { 10, 20 }

	// fmt.Println("aa Equals bb : ", aaa == bbb )
	fmt.Printf("Array aaa Type: %T \n ", aaa )
	fmt.Printf("Array aaa Type: %T \n ", bbb )

	someArray := [...]int { 0: 11, 3: 33, 7: 77 }

	fmt.Println("Array someArray Value : ", someArray )
	fmt.Println("Array someArray Length: ", len( someArray ))
	fmt.Printf("Array someArray Type: %T \n ", someArray )
 // Array someArray Value :  [11 0 0 33 0 0 0 77]
 // Array someArray Length:  8
 // Array someArray Type: [8]int

	someArrayAgain := [...]int{ 99: -555 }
	fmt.Println("someArray : ", someArrayAgain )
	fmt.Println("Length Of someArray: ", len( someArrayAgain ) )
	fmt.Printf("Type Of someArray: %T \n", someArrayAgain )

	var some [4]float64 = [4]float64{ 99.90, 88.8, 111, }
	fmt.Println( "some Array: ", some )

	var ii int = 111
	var ff float64 = 99.99
	fmt.Println( ii, ff )

	// var result = ii + ff
	// fmt.Println( result )

	// var someAgain [3]string = [3]string{ "Ding", "Dong", "Ting", "Tong" }
	// var someAgain [3]string = [3]string{ "Ding", "Dong", 111 }

	var someAgain [3]string = [3]string{ "Ding", "Dong", "Ting" }
	fmt.Println( "someAgain Array: ", someAgain )	
}


//______________________________________________________
//______________________________________________________
//______________________________________________________
//______________________________________________________
//______________________________________________________
//______________________________________________________

func main() {
	fmt.Println("\n\nFunction: playWithArrays")
	playWithArrays()

	fmt.Println("\n\nFunction: playWithArraysAgain")
	playWithArraysAgain()

	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
}

