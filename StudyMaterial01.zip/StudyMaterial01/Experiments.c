
#include <stdio.h>

//__________________________________________________

void playWithArrays() {
	int numbers[5] = { 10, 20, 30, 40, 50 };

	printf("\nValue : %d", numbers[0]);
	printf("\nValue : %d", numbers[1]);
	printf("\nValue : %d", numbers[2]);

	for ( int i = -10 ; i < 10 ; i++ ) {
		printf("\nValue : %d", numbers[i] );
	}
}


//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________

int main() {
	printf("\n\nFunction: playWithArrays");
	playWithArrays();

//	printf("\n\nFunction: ");
//	printf("\n\nFunction: ");
//	printf("\n\nFunction: ");
//	printf("\n\nFunction: ");
//	printf("\n\nFunction: ");
//	printf("\n\nFunction: ");
//	printf("\n\nFunction: ");
//	printf("\n\nFunction: ");
	return 0;
}


